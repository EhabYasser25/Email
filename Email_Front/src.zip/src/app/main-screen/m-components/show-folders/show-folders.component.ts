import { Component } from '@angular/core';

@Component({
  selector: 'app-show-folders',
  templateUrl: './show-folders.component.html',
  styleUrls: ['./show-folders.component.css']
})
export class ShowFoldersComponent {

}
