package com.example.Email_Back.Model.Caches;

public interface Cacheable {
    public String getId();
}
