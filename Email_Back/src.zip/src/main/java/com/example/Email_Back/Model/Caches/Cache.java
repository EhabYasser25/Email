package com.example.Email_Back.Model.Caches;

public interface Cache {

}
